import DetailCard from "../Components/DetailCard";

const Detail = () => {
  return (
    <>
      <DetailCard />
    </>
  )
}

export default Detail