module.exports = {
    moduleDirectories: [
      'node_modules',
      'src/tests/',
      __dirname      
    ]
  }